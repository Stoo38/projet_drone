#!/bin/sh
echo creation du rep  WORK
mkdir ./../WORK
echo copy du run_spy.sh
cp ./run_spy.sh ./../WORK/
echo creation du rep. REPORTS
mkdir ./../REPORTS
echo modifier le fichier defines qui est dans SCRIPTS (lire readme.txt)
echo ce placer dans WORK: "cd ./../WORK"
echo lancer le script: "./run_spy.sh"
echo ENJOIE!!!
